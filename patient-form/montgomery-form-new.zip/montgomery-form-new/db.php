<?php
$conn = mysqli_connect('localhost', 'root', '', 'montgomery_forms');

?>