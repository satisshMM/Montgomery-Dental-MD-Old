<?php
$conn = mysqli_connect('localhost', 'u923672343_montgomeryform', 'Montgomery@123', 'u923672343_montgomeryform');

?>